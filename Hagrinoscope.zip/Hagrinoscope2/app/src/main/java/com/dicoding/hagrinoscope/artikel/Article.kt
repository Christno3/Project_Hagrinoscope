package com.dicoding.hagrinoscope.artikel

data class Article(
    val title: String,
    val content: String,
    val link: String,
)
